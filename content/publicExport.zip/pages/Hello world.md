---
date: 2022-10-07
title: Hello world
tags:
categories:
lastMod: 2022-10-07
---
Hello. This is a [Test page]({{< ref "/pages/Test page" >}}).

![astro.jpg](/assets/astro.jpg)
